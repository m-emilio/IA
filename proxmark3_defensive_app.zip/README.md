
# Proxmark3 Defensive Toolkit

Defensive NFC/RFID auditing GUI with Bluetooth bridge support.

## Features
- Proxmark3 Bluetooth integration
- Live command output
- Reader diagnostics
- Passive tag discovery
- Audit-friendly interface

## Installation

1. Install Node.js
2. Run:

npm install

3. Start Bluetooth bridge:

npm run bridge

4. Start GUI:

npm start

## Example Bluetooth Pairing (Linux)

sudo rfcomm bind /dev/rfcomm0 XX:XX:XX:XX:XX:XX

Replace with your Proxmark3 Bluetooth MAC address.

## Safety

This toolkit is intended strictly for authorized RFID/NFC testing and auditing.
