
const { SerialPort } = require('serialport');
const WebSocket = require('ws');

const portPath = process.env.PM3_PORT || '/dev/rfcomm0';

const port = new SerialPort({
    path: portPath,
    baudRate: 115200
});

const wss = new WebSocket.Server({ port: 8080 });

console.log(`Bluetooth bridge active on ${portPath}`);

port.on('data', (data) => {
    const output = data.toString();

    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(output);
        }
    });
});

wss.on('connection', ws => {
    ws.on('message', msg => {
        port.write(msg.toString() + '\n');
    });
});
