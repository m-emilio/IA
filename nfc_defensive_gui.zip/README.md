
# Defensive NFC Assessment Toolkit

This browser-based toolkit includes:

- APDU Inspector
- Reader Fingerprinting
- Safe Fuzz Harness
- Audit Logging Dashboard

Purpose:
Educational and defensive smart card/NFC testing only.

How to Run:
1. Open index.html in a browser.
2. Navigate through the sidebar tools.
3. Extend functionality with PC/SC, WebUSB, or Proxmark3 integrations.

Safe Use:
This project is intentionally designed to avoid offensive exploitation features.
